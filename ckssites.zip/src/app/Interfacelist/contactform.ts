export class ContactForm
{
    name?:string;
    email?:string;
    subject?:string;
    message?:string;
}