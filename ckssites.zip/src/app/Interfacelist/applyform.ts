export class ApplyForm
{
    name?:string;
    email?:string;
    mobileNo?:string;
    jobName?:string;
    message?:string;
    resumeUrl?:string;
}
export class JobnameForm
{
    JOB_ID?:number;
    JOB_DESCRIPTION?:string;
    JOB_TITLE?:string;
}