import { Component, OnInit } from '@angular/core';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-devapps',
  templateUrl: './devapps.component.html',
  styleUrls: ['./devapps.component.css'],
  providers: [NgbCarouselConfig]
})
export class DevappsComponent implements OnInit {

  constructor(config: NgbCarouselConfig) {
    config.interval = 1000;
    config.wrap = false;
    config.keyboard = false;
    config.pauseOnHover = false;
    config.wrap = true;
   }

  ngOnInit(): void {
  }

}
