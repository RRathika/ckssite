import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LandingComponent } from './landing/landing.component';
import { ItserviceComponent } from './itservice/itservice.component';
import { MenuComponent } from './menu/menu.component';
import { ApplypositionComponent } from './applyposition/applyposition.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ContactComponent } from './contact/contact.component';
import { ConsultingComponent } from './consulting/consulting.component';
import { DevappsComponent } from './devapps/devapps.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { FooterComponent } from './footer/footer.component';
import { GallaryComponent } from './gallary/gallary.component';
import { SidemenuComponent } from './sidemenu/sidemenu.component';
import { CareerComponent } from './career/career.component';
import { BlogComponent } from './blog/blog.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CommonComponent } from './common/common.component';
import { JobnameaddComponent } from './jobnameadd/jobnameadd.component';
import { JobnamelistComponent } from './jobnamelist/jobnamelist.component';
import { NgxSummernoteModule } from 'ngx-summernote';
@NgModule({
  declarations: [
    AppComponent,
    LandingComponent,
    ItserviceComponent,
    MenuComponent,
    ApplypositionComponent,
    ContactComponent,
    ConsultingComponent,
    DevappsComponent,
    AboutusComponent,
    FooterComponent,
    GallaryComponent,
    SidemenuComponent,
    CareerComponent,
    BlogComponent,
    LoginComponent,
    DashboardComponent,
    CommonComponent,
    JobnameaddComponent,
    JobnamelistComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    CommonModule,
    NgbModule,
    BrowserAnimationsModule,
    CarouselModule,
    NgxSummernoteModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
